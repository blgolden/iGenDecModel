#!/bin/bash

set -e
check-imports -b "math/rand,github.com/gonum/.*"
