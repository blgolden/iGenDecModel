// Copyright ©2018 The Gonum Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package parser provides generated internal parsing functions for DOT parsing.
package parser // import "gonum.org/v1/gonum/graph/formats/dot/internal/parser"
