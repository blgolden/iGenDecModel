// herd project doc.go

/*
herd document
*/
package animal
