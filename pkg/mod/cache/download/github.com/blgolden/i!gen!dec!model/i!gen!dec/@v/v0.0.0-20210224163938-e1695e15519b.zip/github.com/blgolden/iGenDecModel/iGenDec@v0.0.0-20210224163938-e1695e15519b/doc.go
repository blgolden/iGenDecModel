// iGenDec project doc.go

/*
iGenDec document
*/
package main
